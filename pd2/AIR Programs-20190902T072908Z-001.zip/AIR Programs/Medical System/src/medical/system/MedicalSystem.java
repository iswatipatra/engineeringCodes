
package medical.system;

public class MedicalSystem 
{
    public static void main(String[] args) 
    {
       new SearchModule().setVisible(true);
    }
    
}
