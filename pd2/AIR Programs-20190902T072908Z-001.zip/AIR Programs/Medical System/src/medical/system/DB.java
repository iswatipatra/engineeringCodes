/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medical.system;

import java.util.*;


/**
 *
 * @author Aditya Ujeniya
 */
public class DB {
    
       Set<Set<String>> dataset = new LinkedHashSet<Set<String>>(); 
       String diseases = "";
            
       void initialize()
       {
            Set<String> symp = new LinkedHashSet<String>();
            symp.add("Coughing");
	       symp.add("Sneezing");
	       symp.add("Blisters");
	       dataset.add(symp);
	       symp = new LinkedHashSet<String>();
	       symp.add("Coughing");
	       symp.add("Sneezing");
	       symp.add("Washing Hands");
	       dataset.add(symp);
	       symp = new LinkedHashSet<String>();
	       symp.add("Coughing");
	       symp.add("Sneezing");
	       symp.add("Rash");
	       dataset.add(symp);
	       symp = new LinkedHashSet<String>();
	       symp.add("Bedding");
	       symp.add("Clothing");
	       symp.add("Infected Skin");
	       dataset.add(symp);
	       symp = new LinkedHashSet<String>();
	       symp.add("Nausea");
	       symp.add("Stomach Ache");
	       symp.add("Jaundice");
	       dataset.add(symp);
	       symp = new LinkedHashSet<String>();
	       symp.add("Nausea");
	       symp.add("Diahorhea");
	       symp.add("Vomiting");
	       dataset.add(symp);
	       symp = new LinkedHashSet<String>();
	       symp.add("Fever");
	       symp.add("Diahorhea");
	       symp.add("Stomach Pain");
	       dataset.add(symp);
       }
       int search(Set<String> sample)
       {
          int flag = 0, i=0;
           for(Set<String> datasetcopy:dataset)
            {
                    if(datasetcopy.equals(sample))
                    {

                        flag = 1;
                        break;
                    }
                    ++i;
            }
            if(flag == 1)
            {
                return i;
            }
            else
            {
                return -1;
            }
       }
    
}
