#define clock_ 13
#define command 11
#define attention 10
#define data 12

#define leftPin2 A4
#define leftPin1 A5
#define rightPin2 A0
#define rightPin1 A1

#define gripperPin1 7
#define gripperPin2 6
#define movePin1 5
#define movePin2 4

